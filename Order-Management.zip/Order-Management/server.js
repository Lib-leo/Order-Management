const express = require('express');
const bodyparser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(bodyparser.json(), cors());
app.use(bodyparser.urlencoded({extended: true}));

app.post('/order', (req,res) => {
    console.log("Request receied", req.body);
    res.send("Order Received")
})

app.get('/getData', (req,res) => {
    res.send([
        {
            name: "Anushiya",
            number: "7942873845"
        },
        {
            name: "Anjana",
            number: "9367264723"
        },
        {
            name: "Amoon",
            number: "2346674987"
        },
        {
            name: "Liz",
            number: "3648732677"
        }
    ])
})

var server = app.listen(4000, () => {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Listening in port", host, port);
})
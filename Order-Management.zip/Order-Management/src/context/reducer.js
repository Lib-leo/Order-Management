export const REDUCER = (state, action) => {
	const { payload } = action;
	switch (action.type) {
		case 'UPDATE_MENU': {
			// payload.menu.category.map(item => (item.image = require('../assets/buttons'+item["image-url"])))
			return {
				...state,
				...payload
			};
		}
		case 'CHANGE_QUANTITY': {
			let { order } = state;
			let { items } = order;
			let newOrder = {};
			if(payload.quantity === 0){
				const filteredItems = items.filter(item => item.id !== payload.id);
				newOrder = { ...order, items: filteredItems };
			}
			else{
				let { order } = state;
				let { items } = order;
				items.filter(item => item.id === payload.id)[0].quantity = payload.quantity;
				newOrder = { ...order, items: items };
			}
			
			return {
				...state,
				order: newOrder
			}
		}
		case 'ADD_ORDER': {
			let { order } = state;
			let { items } = order;
			let filteredOrder = items.filter(item => item.id !== payload.id)
			let newItem = [...filteredOrder, payload];
			let newOrder = { ...order, items: newItem }
			return {
				...state,
				order: newOrder,
			};
		}
		case 'ORDER_CONFIRMED': {
			let {order} = state
			const newOrder = {...order, status: payload}
			return {
				...state,
				order: newOrder
			}
		}
		case 'ADD_GUEST':{
			let { order } = state;
			let newOrder = { ...order, guestName: payload }
			return {
				...state,
				order: newOrder,
			};
		}
		// case 'NETWORK_CHANGE':{
		// 	return {
		// 		...state,
		// 		network: payload
		// 	}
		// }
		case 'CANCEL_ITEMS': {
			let { order } = state;
			let newOrder = { ...order, items: [], guestName: [],time:payload, status: null }
			return {
				...state,
				order: newOrder,
			};
		}
		case 'CHANGE_TABLE': {
			let { order } = state;
			let newOrder = { ...order, tableNo: payload.table.toString(), seats: payload.seat.toString() }
			return {
				...state,
				order: newOrder
			}
		}
		case 'CANCEL_ORDER': {
			let { order } = state;
			let { items } = order;
			const filteredOrder = items.filter(item => item.id !== payload)
			let newItem = [...filteredOrder];
			let newOrder = { ...order, items: newItem }
			return {
				...state,
				order: newOrder,
			};
		}
		case 'SET_MENU_CATEGORY':
			return {
				...state,
				selectedMenu: payload
			}
		case 'CHANGE_THEME':
			return {
				...state,
				theme: payload
			}
			
		case 'CHANGE_SINCE_TIME':
			let {order} = state;
			let newOrder = { ...order, time: payload }
		return {
			...state,
			order: newOrder
		}
		default:
			return state;
	}
};

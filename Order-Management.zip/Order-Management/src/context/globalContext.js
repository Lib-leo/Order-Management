import React, { useEffect, useMemo, useReducer, createContext, useCallback } from 'react';
import { REDUCER } from './reducer';
import menuList from '../mocks/menu.json';
// import moment from 'moment';
// import axios from 'axios';

const GlobalContext = createContext();
const GlobalContextProvider = (props) => {
    const [state, dispatch] = useReducer(REDUCER, {
        menu: {},
        selectedMenu: "1",
        order: {
            username: 'Kayathi. D',
            checkNumber: 40233,
            time: new Date(),
            guestName: [],
            tableNo: '3',
            seats: '4',
            items: [],
            status: null
       },
    });

    const fetchMenu = useCallback(() => {
        try {
//             let {data} = await axios.get('https://4k4us89ly4.execute-api.us-east-1.amazonaws.com/darden/order', {
//                 crossDomain: true
//               })
//             //   { crossdomain: true }
// // https://4k4us89ly4.execute-api.us-east-1.amazonaws.com/darden/order
// //https://darden.s3.ap-south-1.amazonaws.com/resources/menu.json

//             console.log("Data Received: ", data);
            dispatch({type:'UPDATE_MENU', payload: menuList});
        } 
        catch (error){
            console.log(error);
        }
    }, []);
    useEffect(() => {
        fetchMenu()
    }, [fetchMenu]);

   

        const value = useMemo(() => {
        return {state, dispatch}
    }, [ state]);


    if (state?.loading)
        return <div>Loading Indicator</div>

    return <GlobalContext.Provider value={value}>
        {props.children}
    </GlobalContext.Provider>
};



export { GlobalContextProvider, GlobalContext }

import axios from 'axios';
import moment from 'moment';
import url from '../../Constants/url.json';

export const confirmOrder = async(order)=> {
    try {
        let finalcheck = 0;
        let itemList = [];
        let itemListKitchen = [];
        let guests = [];
        order.guestName.map(guest => {
            guests.push({name: guest});
            return guest;
        })
        order.items.map((item, id) => {
           finalcheck = finalcheck + (Number(item.price.slice(1,item.price.length)) * item.quantity)
           itemList.push({
            itemno: item.id,
            quantity: item.quantity,
            price: item.price
           })
           itemListKitchen.push({
               quantity: item.quantity,
               name: item.name,
               itemno: item.id,
               section: item.section,
               preparation: item.preparation,
               status: "progress"
           })
           return item;
        })
        const data = {
            server: order.username,
            guests: guests,
            datetime: moment(order.time).format('yyyy-MM-DD HH:mm:ss'),
            tableno: order.tableNo,
            seats: order.seats,
            items: itemList,
            check: finalcheck 
        }
        let response = await axios.post(url["post-order-url"], data, {
           crossOrigin: true,
        })
        const data1 =  {
            orderid: response.data.id,
            tablenumber: order.tableNo,
            datetime: moment(order.time).format('yyyy-MM-DD HH:mm:ss'),
            server: order.username,
            status: "Progress",
            items: itemListKitchen
        }
        let response1 = await axios.post(url["post-kitchen-url"], data1, {
            crossOrigin: true
        })
        console.log("response: ", response1);
        return response.data.message;
    } 
    catch (error){
        console.log(error);
    }
}
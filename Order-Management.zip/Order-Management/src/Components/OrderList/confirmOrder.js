import React from 'react';
import { GlobalContext } from '../../context/globalContext';
import {Modal, Dropdown, DropdownButton} from 'react-bootstrap'
import {confirmOrder} from './order.service';
import './orderList.css';
import moment from 'moment';


const ConfirmOrderModal = ({onHide, isOrder}) => {
    const {state: GlobalState, dispatch}= React.useContext(GlobalContext);
    const {order} = GlobalState;
    let finalcheck = 0;
    order.items.map((item) => {
        finalcheck = finalcheck + (Number(item.price.slice(1,item.price.length)) * item.quantity)
        return item;
    })
    const confirmOrderDetails = async() => {
        onHide();
        dispatch({type: 'ORDER_CONFIRMED', payload: 'Order Processing...'})
        let response = await confirmOrder(order);
        if(response === "Success"){
            dispatch({type: 'ORDER_CONFIRMED', payload: 'Order Placed'})
           
        }
        else{
            dispatch({type: 'ORDER_CONFIRMED', payload: 'Awaiting for order confirmation'})
            // dispatch({type: 'CANCEL_ITEMS'})
        }
    }
    const increaseOrderNumber = (id) => {
        const quantity = order.items.filter(data1 => data1.id === id)[0].quantity + 1;
        dispatch({type: 'CHANGE_QUANTITY', payload: {id: id, quantity: quantity}})
    }

    const decreaseOrderNumber = (id) => {
        const quantity = order.items.filter(data1 => data1.id === id)[0].quantity - 1;
        dispatch({type: 'CHANGE_QUANTITY', payload: {id: id, quantity: quantity}});
    }
    const removeItem = (id) =>{
        const quantity = 0;
        dispatch({type: 'CHANGE_QUANTITY', payload: {id: id, quantity: quantity}});
    }
    const cancelItems = () => {
        onHide();
        dispatch({type: 'CANCEL_ITEMS',payload: new Date() })
    }

    return (
        <React.Fragment>
            {isOrder ? <Modal.Header closeButton>
            </Modal.Header> : null}
            <Modal.Body>
            <div className="orderlist-header row">
                <div className="col-4">{order.username}</div>
                <div className="col-4">Check : {order.checkNumber}</div>
                <div className="col-4 text-right">Since : {moment(order.time.getTime()).format('h:mm A')}</div>
            </div>
            <div className="orderlist-user">
                <div className="row">
                    <div className="col-3">{order.guestName}</div>
                </div>
                <div className="row">
                    <div className="col-3">
                        Table {order.tableNo}
                    </div>
                    <div className="col-3">
                        Seat {order.seats}
                    </div>
                </div>
            </div>
            <div>
                <div className="orderlist-list">
                    <table>
                        <thead>
                            <tr>
                                <th>#item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                        {order.items.map(item =>
                        <tr>
                            <td>{item.name}</td>
                            {
                                isOrder ? 
                                <td>
                                    <span className="plusbutton" onClick={() => decreaseOrderNumber(item.id)} >-</span>
                                    <span className="qtyvalue">
                                        {item.quantity >= 0 ? item.quantity : null}
                                    </span>
                                    <span className="minusbtn" onClick={() => increaseOrderNumber(item.id)}>+</span>
                                </td>
                                :
                                <td>{item.quantity}</td>
                            }
                            <td> {(Number(item.price.slice(1,item.price.length)) * item.quantity).toFixed(2)} </td>
                            {isOrder ? <td>
                                <DropdownButton
                                    id={`item-dropdown`}
                                    drop={'left'}
                                    title={`...`}
                                >
                                    <Dropdown.Item onClick={()=> removeItem(item.id)}>Remove Item</Dropdown.Item>
                                </DropdownButton></td>
                                : null}
                        </tr>)}
                        </tbody>
                    </table>
                    {isOrder ? null :<div>Check: ${finalcheck.toFixed(2)}</div>}
                </div>
                {isOrder && order.status ? <div>Order Status: <div className="order-status">{order.status}</div></div> : null }
                </div>
            </Modal.Body>
            
            <Modal.Footer>
            {isOrder ? <React.Fragment>
                {order.status ? <button type="button" class="order-new-btn" onClick={() => cancelItems()}>New Order</button> : null}
            </React.Fragment>
            :
                <React.Fragment>
                    <button className="order-modal-confirm-btn" onClick={() => confirmOrderDetails()}>
                        Confirm Order
                    </button>
                    <button className="order-modal-cancel-btn" onClick={onHide}>
                        Close
                    </button>
                </React.Fragment>
            }
            </Modal.Footer>
        </React.Fragment>
    )
}

export default ConfirmOrderModal;

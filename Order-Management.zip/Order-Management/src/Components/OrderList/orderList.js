import React from 'react';
import { GlobalContext } from '../../context/globalContext';
import './orderList.css';
import { Modal } from 'react-bootstrap';
import ConfirmOrderModal from './confirmOrder';
import moment from 'moment';


const OrderList = () => {
    const {state: GlobalState, dispatch}= React.useContext(GlobalContext);
    const [showPopup, setShowPopup] = React.useState(false);
    const {order} = GlobalState;
    let guest = '';
    if(order.guestName){
        order.guestName.map((guestVal, id) => {
            if(id === 0){
                guest = guest + guestVal;
            }
            else{
                guest = guest + ', ' + guestVal;
            }
            return guestVal;
        })
    }
    const cancelItems = () => {
        dispatch({type: 'CANCEL_ITEMS',payload: new Date() })
    }
    const handlePopup = () => {
        setShowPopup(!showPopup)
    }
    const increaseOrderNumber = (id) => {
        const quantity = order.items.filter(data1 => data1.id === id)[0].quantity + 1;
        dispatch({type: 'CHANGE_QUANTITY', payload: {id: id, quantity: quantity}})
      }
    
      const decreaseOrderNumber = (id) => {
        const quantity = order.items.filter(data1 => data1.id === id)[0].quantity - 1;
        dispatch({type: 'CHANGE_QUANTITY', payload: {id: id, quantity: quantity}});
      }
    return (
        <div className="orderlist-container">
            <div className="orderlist-header row">
                <div className="col-4">{order.username}</div>
                <div className="col-4">Check : {order.checkNumber}</div>
                <div className="col-4 text-right">Since : {moment(order.time.getTime()).format('h:mm A')}</div>
            </div>
            <div className="orderlist-user">
                <div className="row">
                    <div className="col">{guest}</div>
                </div>
                <div className="row">
                    <div className="col-4">
                        Table {order.tableNo}
                    </div>
                    <div className="col-4">
                        Seat {order.seats}
                    </div>
                </div>
            </div>
            {order.items.length ?
            <div>
                <div className="orderlist-list">
                    <table>
                        <thead>
                            <tr>
                                <th>#item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        {order.items.map(item =>
                        <tr >
                            <td>{item.name}</td>
                            <td>
                                <span className="plusbutton" onClick={() => decreaseOrderNumber(item.id)} >-</span>
                                <span className="quantityvalue">
                                    {item.quantity >= 0 ? item.quantity : null}
                                </span>
                                <span className="minusbutton" onClick={() => increaseOrderNumber(item.id)}>+</span>
                            </td>
                            <td> {(Number(item.price.slice(1,item.price.length)) * item.quantity).toFixed(2)} </td>
                        </tr>)}
                      
                        </tbody>
                    </table>
                </div>
                <div className="orderlist-btn">
                    {order.status ? <div>
                        <div className="order-status">{order.status}</div>
                        <button type="button" class="order-new-btn" onClick={() => cancelItems()}>New Order</button>
                    </div>
                    : <div><button type="button" class="order-confirm-btn" onClick={() => handlePopup()}>Place Order</button>
                    <button type="button" class="order-cancel-btn" onClick={() => cancelItems()}>New Order</button></div>
                    }
                    
                </div>
            </div>
             : null}
             <Modal show={showPopup} onHide={handlePopup} centered>
                 <ConfirmOrderModal onHide={handlePopup}/>
             </Modal>
        </div>
    )
}

export default OrderList;

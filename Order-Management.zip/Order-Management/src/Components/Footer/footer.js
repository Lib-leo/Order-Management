import React from 'react';
import './footer.css';
import { Modal } from 'react-bootstrap';
import ConfirmOrderModal from '../OrderList/confirmOrder';
import { GlobalContext } from '../../context/globalContext';
import { Logout, CheckoutImage, Home, OrderImage } from '../../assets/icons';

const Footer = () => {
    const [showOrderPopup, setOrderPopup] = React.useState(false);
    const [showConfirmPopup, setConfirmPopup] = React.useState(false);
    const { state: GlobalState, dispatch } = React.useContext(GlobalContext);
    const { order } = GlobalState;
    const handleOrderModal = () => {
        setOrderPopup(!showOrderPopup);
    }
    const handleConfirmModal = () => {
        setConfirmPopup(!showConfirmPopup);
    }
    const logout = () => {
        document.location.href="https://yellow-smoke-08e6dab10.azurestaticapps.net/";
    }
    const newOrder = () => {
        dispatch({ type: 'CANCEL_ITEMS', payload: new Date() })
    }
    return (
        window.innerWidth >= 550 ?
            <div className="footer row">
                Darden Restaurants
        </div>
            :
            <React.Fragment>
                <div className="row footer-1">
                    {console.log("Status: ", showOrderPopup, showConfirmPopup)}
                    <button className="col-3 footer-btn" onClick={() => logout()}>
                        <img src={Logout} alt="logout" className="col imageContainer" />Logout
                    </button>
                    <button className="col-3 footer-btn" onClick={() => newOrder()}>
                        <img src={Home} alt="home" className="col imageContainer" />Home
                    </button>
                    <button type="button" className="col-3 footer-btn" onClick={() => order.items.length > 0 ? handleOrderModal() : null}>
                        <img src={OrderImage} alt="orders" className="col imageContainer" />Orders
                    </button>
                    <button type="button" className="col-3 footer-btn" onClick={() => order.items.length > 0 ? order.status ? null : handleConfirmModal() : null}>
                        <img src={CheckoutImage} alt="placeorders" className="col imageContainer" />Place Order
                    </button>
                </div>
                <Modal show={showOrderPopup} onHide={handleOrderModal} centered>
                    <ConfirmOrderModal onHide={handleOrderModal} isOrder={true} />
                </Modal>
                <Modal show={showConfirmPopup} onHide={handleConfirmModal} centered>
                    <ConfirmOrderModal onHide={handleConfirmModal} isOrder={false} />
                </Modal>
            </React.Fragment>
    )
}

export default Footer;
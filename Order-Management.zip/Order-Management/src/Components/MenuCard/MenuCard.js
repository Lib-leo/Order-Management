/* eslint-disable */
import React, { useState } from 'react';
import { GlobalContext } from '../../context/globalContext';
import { icedtea_btn } from '../../assets/buttons';
import './menu.css'
import Table from './table';

function MenuCard() {
  const { state: GlobalState, dispatch } = React.useContext(GlobalContext);
  const [menudetail, setMenuDetails] = useState({});
  const { order, menu, selectedMenu } = GlobalState;

  React.useEffect(() => {
    if (menu && menu.category && menu.category.length) {
      let selectedMenuItem = menu.category.filter(data => data.id === selectedMenu)[0];
      if (selectedMenuItem && selectedMenuItem.items && selectedMenuItem.items.length) {
        selectedMenuItem.items.map(data1 => {
          let item = order.items.filter(data => data.id === data1.id);
          if (item.length === 0) {
            data1.quantity = 0;
            data1.addedquantity = 0;
          }
          else {
            if (item[0].quantity !== data1.quantity) {
              data1.quantity = item[0].quantity;
              data1.addedquantity = item[0].quantity;
            }
          }
          try {
            data1.image = require('../../assets/buttons/' + data1['image-url']);
          }
          catch {
            data1.image = icedtea_btn;
          }
          return data1;
        })
        setMenuDetails(selectedMenuItem);
      }
    }
  }, [menu, selectedMenu]);


  React.useEffect(() => {
    if (order.items.length === 0 && menudetail && menudetail.items && menudetail.items.length) {
      menudetail.items.map(data1 => {
        data1.quantity = 0;
        data1.addedquantity = 0;
        return data1;
      })
      setMenuDetails({ ...menudetail });
    }
    if (order.items.length !== 0 && menudetail && menudetail.items && menudetail.items.length) {
      let id;
      menudetail.items.map(data1 => {
        order.items.map(item => {
          if (item.id === data1.id && item.quantity !== data1.quantity) {
            id = item.id
            return item
          }
          return item
        })
        return data1
      })
      if (id) {
        menudetail.items.filter(data1 => data1.id === id)[0].quantity = order.items.filter(data1 => data1.id === id)[0].quantity;
        menudetail.items.filter(data1 => data1.id === id)[0].addedquantity = order.items.filter(data1 => data1.id === id)[0].quantity;
        setMenuDetails({ ...menudetail });
      }
      let id1;
      menudetail.items.map(itemIn => {
        if (itemIn.quantity > 0) {
          let item = order.items.filter(data => data.id === itemIn.id);
          if (item.length === 0) {
            id1 = itemIn.id
          }
        }
      })
      if (id1) {
        menudetail.items.filter(data1 => data1.id === id1)[0].quantity = 0;
        menudetail.items.filter(data1 => data1.id === id1)[0].addedquantity = 0;
        setMenuDetails({ ...menudetail });
      }
    }
  }, [order])


  const increaseOrderNumber = (id) => {
    menudetail.items.filter(data1 => data1.id === id)[0].quantity++
    setMenuDetails({ ...menudetail });
  }

  const decreaseOrderNumber = (id) => {
    menudetail.items.filter(data1 => data1.id === id)[0].quantity--
    setMenuDetails({ ...menudetail });
  }

  const addOrder = (e, item) => {
    e.preventDefault();
    let obj = {};
    obj.id = item.id;
    obj.name = item.name;
    obj.quantity = menudetail.items.filter(data1 => data1.id === item.id)[0].quantity;
    obj.price = menudetail.items.filter(data1 => data1.id === item.id)[0].price;
    obj.section = menudetail.items.filter(data1 => data1.id === item.id)[0].section;
    obj.preparation = menudetail.items.filter(data1 => data1.id === item.id)[0].preparation;
    if (obj.quantity > 0) {
      dispatch({ type: "ADD_ORDER", payload: obj });

      menudetail.items.filter(data1 => data1.id === item.id)[0].display = false;
      menudetail.items.filter(data1 => data1.id === item.id)[0].addedquantity = menudetail.items.filter(data1 => data1.id === item.id)[0].quantity;
      setMenuDetails({ ...menudetail });
    }
  }

  const displayOverlay = (id) => {
    menudetail.items.filter(data1 => data1.id === id)[0].display = !menudetail.items.filter(data1 => data1.id === id)[0].display;
    menudetail.items.filter(data1 => data1.id === id)[0].quantity = menudetail.items.filter(data1 => data1.id === id)[0].addedquantity;
    setMenuDetails({ ...menudetail });
  }

  const cancelOrder = (e, item) => {
    e.preventDefault();
    menudetail.items.find(data => data.id === item.id).quantity = 0;
    dispatch({ type: "CANCEL_ORDER", payload: item.id });
    menudetail.items.filter(data1 => data1.id === item.id)[0].display = false;
    menudetail.items.filter(data1 => data1.id === item.id)[0].addedquantity = 0;
    setMenuDetails({ ...menudetail });
  }

  return (
    <div className="menucontainer">
      <Table />
      <div className="menuimage-container">
        {menudetail && menudetail.items && menudetail.items.length && menudetail.items.map(item =>
          <>
            {window.innerWidth < 550 ? <>
              <div className="image" onClick={() => displayOverlay(item.id)} >
                <img src={item.image} className="image__img" />
                <div className="title">{item.name}</div>
                {item.quantity > 0 ? <div className="item-quantity text-right">{item.quantity}</div> : null}
              </div>
              {item.display ?
                <div id={`overlay-menu-${item.id}`} class="imageOverlay" >
                  <div class="text">
                    <div className="symbol">
                      <div className="plusbutton" onClick={() => decreaseOrderNumber(item.id)} >-</div>
                      <div className="quantityvalue">
                        {item.quantity >= 0 ? item.quantity : 0}
                      </div>
                      <div className="minusbutton" onClick={() => increaseOrderNumber(item.id)}>+</div>
                    </div>
                    <div className="buttonContainer">
                      <button className="addbutton" onClick={(e) => addOrder(e, item)}>Add</button>
                      <button className="cancelbutton" onClick={(e) => cancelOrder(e, item)}>Cancel</button>
                    </div>
                  </div>
                </div>
                :
                null}
            </> :
              <div className="image">
                <img src={item.image} className="image__img" />
                <div className="title">{item.name}</div>
                <div class="image__overlay image__overlay--primary" onMouseLeave={() => displayOverlay(item.id)}>
                  <div class="text">
                    <div className="symbol">
                      <div className="plusbutton" onClick={() => decreaseOrderNumber(item.id)} >-</div>
                      <div className="quantityvalue">
                        {item.quantity >= 0 ? item.quantity : null}
                      </div>
                      <div className="minusbutton" onClick={() => increaseOrderNumber(item.id)}>+</div>
                    </div>
                    <div className="buttonContainer">
                      <button className="addbutton" onClick={(e) => addOrder(e, item)}>Add</button>
                      <button className="cancelbutton" onClick={(e) => cancelOrder(e, item)}>Cancel</button>
                    </div>
                  </div>
                </div>
              </div>
            }

          </>
        )}
      </div>
    </div>

  );
}

export default MenuCard;

import React from 'react';
import { GlobalContext } from '../../context/globalContext';
import table from '../../mocks/table.json';

const Table = () => {
    const { state: GlobalState, dispatch } = React.useContext(GlobalContext);
    const [selectedTable, setSelectedTable] = React.useState(null);
    const [arrLimit, setArrLimit] = React.useState(10);
    const [value, setValue] = React.useState(0);
    const changeValue = (table) => {
        if(table.table){
            setValue(0);
            dispatch({type: 'CHANGE_TABLE', payload: table})
        }
        else{
            table = document.getElementById('table').value;
            setValue(table)
            table = JSON.parse(table)
            dispatch({type: 'CHANGE_TABLE', payload: table})
        }
    }
    const setLimitValue = (width) => {
        if(width <= 550){
            setArrLimit(4)
        }
        else if(width <= 882) {
            setArrLimit(5)
        }
        else if(width <= 1020){
            setArrLimit(7)
        }
        else if(width <= 1162){
            setArrLimit(8)
        }
        else if(width <= 1346){
            setArrLimit(9)
        }
    }
    React.useEffect(()=>{
        setSelectedTable(GlobalState.order.tableNo)
        window.addEventListener("resize", () => setLimitValue(window.innerWidth));
        setLimitValue(window.innerWidth)
        return () => window.addEventListener("resize", () => setLimitValue(window.innerWidth));
    },[GlobalState])
    return(
        <div className="row selectTable-container">
            <div className={`${window.innerWidth <= 783 ? window.innerWidth <= 510 ? "col-8": "col-9" : "col-10"}`}>
                <div className="row">
                    {table.map(table => {
                        if(table.table < arrLimit)
                            return(
                            <div className={`col table-col ${table.table.toString() === selectedTable ? 'selected-table' : null}`} onClick={() => changeValue(table)}>
                                Table {table.table}
                            </div>)
                        else
                            return null
                    })}
                </div>
            </div>
            <div className={`${window.innerWidth <= 783 ? window.innerWidth <= 510 ? "col-4": "col-3" : "col-2"} table-col ${selectedTable >= arrLimit ? 'selected-table' : null}`}>
                <select id="table" value={value} className={`table-select ${selectedTable >= arrLimit ? 'selected-table' : null}`} onChange={changeValue}>
                    <option value={0}> {`Select a Table`} </option>
                    {table.map(table => {
                        if(table.table >= arrLimit)
                            return(
                            <option className="table-option" value={JSON.stringify(table)}>
                                Table {table.table}
                            </option>)
                        else
                            return null
                    })}
                </select>
            </div>
        </div>
    )
}

export default Table;

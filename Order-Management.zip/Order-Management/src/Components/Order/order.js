import React, { useState } from 'react';
// import axios from 'axios';
import Header from '../Header/header';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../App.css';
import MenuCard from '../MenuCard/MenuCard';
import OrderList from '../OrderList/orderList';
import MenuList from '../MenuList/menuList';
import { search } from '../../assets/icons';
import Footer from '../Footer/footer';
import { GlobalContext } from '../../context/globalContext';
//import { keepTheme } from './utils/themes';

function Order() {
  //   React.useEffect(() => {
  //     keepTheme();
  // })
  const { state: GlobalState, dispatch } = React.useContext(GlobalContext);
  const { order } = GlobalState;
  const [guest, setGuest] = useState('');
  const handleChange = () => {
    const guestValue = document.getElementById('guest').value;
    setGuest(guestValue)
  }
  React.useEffect(() => {
    if (order && order.guestName && order.guestName.length === 0) {
      setGuest('');
    }
  }, [order]);
  const addGuest = () => {
    const guestValue = document.getElementById('guest').value;
    if (guestValue !== '') {
      let valueArray = guestValue.split(',')
      dispatch({ type: "ADD_GUEST", payload: valueArray });
      setGuest(guestValue);
    }
  }
  return (

    <div className="App">
      {console.log(window.innerWidth)}
      {/* <Toggle theme={theme} toggleTheme={toggleTheme} /> */}
      <div style={{ overflowY: "auto", overflowX: "hidden" }}>
        <Header />
        <div className="search row">

          {window.innerWidth < 550 ?
            <>
              <div className="col-12">
                <img src={search} alt="search" style={{ width: "20px", height: "20px" }} />
                <input type="text" className="input-search" placeholder="Search" style={{ marginLeft: "10px" }} />
              </div>
              <div className="col-12">
                <input type="text" id="guest" className="input-search" placeholder={"Guest Name"} onChange={handleChange} value={guest} style={{ width: "61%" }} />{' '}
                <button type="button" className="guest-btn" onClick={() => addGuest()}>Add Guest</button>
              </div>
            </>
            : <>
              <div className="col-6">
                <img src={search} alt="search" />
                <input type="text" className="input-search" placeholder="search" />
              </div>
              <div className="col-6 text-right">
                <input type="text" id="guest" className="input-search" placeholder={"Guest Name"} onChange={handleChange} value={guest} />{' '}
                <button type="button" className="guest-btn" onClick={() => addGuest()}>Add Guest</button>
              </div></>}
        </div>
        <div className="menulist">
          <MenuList />
        </div>
        <div className="row">
          <div className="menudetail">
            <MenuCard />
          </div>
          <div className={`orderlist`}>
            <OrderList />
          </div>
        </div>
      </div>
      <Footer />
    </div>

  );
}

export default Order;

import React,{useState} from 'react';
import {useNavigate} from 'react-router-dom';
import './Login.css';
import './bootstrap.min.css';
// import image from '../../assets/Ellipse 1.png';
import chef from '../../assets/chef_image.png';
import NetworkDetector from '../Network/NetworkDetector';
 
// HEADER COMPONENT 
function HeaderComp() {
  const [error,setError]=useState(''); 
  const [loginid, setLoginid] = useState('');
  const navigate = useNavigate();
  const checkUser = event => {
    let data=event.target.value;
    if((/^([0-9]{1,5})$/.test(data))){
      setError('')
      setLoginid(data)
    }else if(data.length===0){
      setError('')
      setLoginid(data)
    }else{
      setError('Enter a valid Number!!!')
    }
  }
  const login = () => {
    
    if(error === '' && loginid !== ''){
      if(loginid==='12345')
        navigate('/Order');
      else
        setError('Invalid Login ID')
    }
    else{
      setError('Enter Login ID')
    }
  }
  return (
    <div>
    <div className="page-height">
    <div className="page-header-ls row noMargin" >
        <div className="menu-items-ls" >
          CND80673DV
        </div> 
        <div className="menu-items-ls-1" >
          <NetworkDetector />
        </div>
      </div>
      <div className="row noMargin info-area">
        <div className="login-section">
          <div className="dash-container">
            <div className="dash-style">
              DASH
            </div>
          <div className="text-style">
              Darden Application For Services & Hospitality
          </div>
          </div>
          <div className="search-container">
            <div className="input-div row">
              <div className="input-div-1">
              <input type="password" id="name" name="name" className="input-style no-outline" placeholder="Login" onChange={checkUser}/>
              </div>
              <div className="input-div-2">
              <button type="button" className="button-div" onClick={() => login()}>Go</button>
              </div>
            </div>
          </div>
          <div className="error-container">
          {error}
          </div>
          <div className="rules-container">
            <div className ="yrs-style">
              21 yrs old id born on or before 
            </div>
            <div className="date-style">
              Dec 10, 1997
            </div>
          </div>
        </div>
        <div className="picture-section">
          <img alt="ellipse" src={chef} className="chef-image"/>
        </div>
      </div>
    </div>
  </div>
  );
}
 
export default HeaderComp;
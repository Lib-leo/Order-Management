/* eslint-disable */
import React, { Component } from 'react';
import { Green_icon, white_icon } from '../../assets/buttons';
import './network.css';
import { GlobalContext } from '../../context/globalContext';

class NetworkDetector extends Component {
    static contextType = GlobalContext;
    constructor(props) {
        super(props);
    }
    state = {
        isDisconnected: false
    }

    componentDidMount() {
        this.handleConnectionChange();
        window.addEventListener('online', this.handleConnectionChange);
        window.addEventListener('offline', this.handleConnectionChange);
    }

    componentWillUnmount() {
        window.removeEventListener('online', this.handleConnectionChange);
        window.removeEventListener('offline', this.handleConnectionChange);
    }


    handleConnectionChange = () => {
        const condition = navigator.onLine ? 'online' : 'offline';
        if (condition === 'online') {
            const webPing = setInterval(
                () => {
                    fetch('//google.com', {
                        mode: 'no-cors',
                    })
                        .then(() => {
                            if(this.context.state.order.status === 'Awaiting for order confirmation'){
                                this.context.dispatch({type: 'ORDER_CONFIRMED', payload: 'Order Placed'})
                            }
                            this.setState({ isDisconnected: false }, () => {
                                return clearInterval(webPing)
                            });
                        }).catch(() => {
                            if(this.context.state.order.status === 'Awaiting for order confirmation'){
                                this.context.dispatch({type: 'ORDER_CONFIRMED', payload: 'Order Placed'})
                            }
                            this.setState({ isDisconnected: true })
                        })
                }, 2000);
            return;
        }
        return this.setState({ isDisconnected: true });
    }

    render() {
        const { isDisconnected } = this.state;
        return (
            <div>
               
                {isDisconnected ? <>OFFLINE &nbsp;<img src={white_icon} className="white_icon" /></> : <>ONLINE &nbsp;<img src={Green_icon} className="green_icon" /></>}
                    

            </div>
        );
    }
}

export default NetworkDetector;

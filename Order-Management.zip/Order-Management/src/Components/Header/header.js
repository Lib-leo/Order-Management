import React, { useState, useEffect } from 'react';
import './header.css';
// import Toggle from '../Toggle/toggle';
import NetworkDetector from '../Network/NetworkDetector';
import moment from 'moment';
const Header = () => {
    var [date, setDate] = useState();
    const currentdate = moment(date).format('D MMM YYYY');
    const day = moment(date).format('ddd');
    const time = moment(date).format('h:mm A');
    useEffect(() => {
        var timer = setInterval(() => setDate(moment()), 1000)
        return function cleanup() {
            clearInterval(timer)
        }

    });
    const logout = () => {
        document.location.href="https://yellow-smoke-08e6dab10.azurestaticapps.net/";
    }
    return (
        <>
            {console.log("header", window.innerWidth)}
            {window.innerWidth < 550 ?
                <div className="header">
                    <div className="header-left col">
                        <div className="col">CND 80673DV</div>
                        <div className="col">KAYATHI. D</div>
                    </div>
                    {/* Light
                        <div className="col">
                        <Toggle />
                        <div style={{marginLeft:"68px"}}>Dark</div>
                    </div> */
                    }
                    <div className="header-right col">
                        <div className="col" style={{ marginLeft: "26px" }}>
                            <NetworkDetector />
                        </div>
                        <div className="col" style={{ marginLeft: "26px", }}>{day.toUpperCase()} {time} </div>
                        <div className="col" style={{ marginLeft: "26px" }}>{currentdate.toUpperCase()}</div>
                    </div>
                </div>
                :
                <div className="header row">
                    <div className="col-sm-2">CND 80673DV</div>
                    <div className="col-sm-2">KAYATHI. D</div>
                    {/* Light
                        <div className="col">
                        <Toggle />
                        <div style={{marginLeft:"68px"}}>Dark</div>
                        </div> */
                    }
                    <div className="col-sm-2">
                        <NetworkDetector />
                    </div>
                    <div className="col-sm-2 text-right">{currentdate}</div>
                    <div className="col-sm-2 text-center">{day} {time} </div>
                    <button className="col-sm-2 logout-btn" onClick={() => logout()}>Logout</button>
                </div>
            }
        </>
    )
}

export default Header;
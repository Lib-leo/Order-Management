/* eslint-disable */
import React, { useEffect, useState } from 'react';
import { GlobalContext } from '../../context/globalContext';
import { left_arrow, non_alh_bev_btn, right_arrow } from '../../assets/buttons';
import './menuList.css';


const MenuList = () => {
    const {state: GlobalState, dispatch}= React.useContext(GlobalContext);
    // const [end, setEnd] = useState(7);
    const { menu, selectedMenu } = GlobalState;
    const [currentMenuList, setCurrentMenuList] = useState([]);
    let start = 0;
    const [startIndex, setStartIndex] = useState(start);
    const [endIndex, setEndIndex] = useState(7);
    const setEndValue = (width) => {
        if(width <= 550){
            setEndIndex(3)
        }
        else if(width<=644)
            setEndIndex(2)
        else if(width <= 800){
            setEndIndex(3)
        }
        else if(width <= 930){
            setEndIndex(4)
        }
        else if(width <= 1176){
            setEndIndex(5)
        }
    }
    
    useEffect(() => {
        window.addEventListener("resize", () => setEndValue(window.innerWidth));
        setEndValue(window.innerWidth)
        return () => window.addEventListener("resize", () => setEndValue(window.innerWidth));
      }, []);
    if(menu && menu.category && menu.category.length > 0){
        menu.category.map(data => {
            try{
                return data.image = require('../../assets/buttons/'+data["image-url"])
            }
            catch{
                return data.image = non_alh_bev_btn;
            }
        }
            
        )
    }
    React.useEffect(() => {
        if(menu && menu.category && menu.category.length > 6){
            setCurrentMenuList(menu.category.slice(startIndex,endIndex));
        }
        else{
            setCurrentMenuList(menu.category)
        }
    }, [menu, startIndex, endIndex])
    
    // else{
    //     setCurrentMenuList(menu.category)
    // }
    const leftArrowFunc = () => {
        setStartIndex(startIndex - 1);
        setEndIndex(endIndex - 1);
    }
    const rightArrowFunc = () => {
        setStartIndex(startIndex + 1);
        setEndIndex(endIndex + 1);
    }
    const setSelectedMenuCategory = (id) => {
        dispatch({type: "SET_MENU_CATEGORY", payload: id});
    }
    return (
        // window.innerWidth >= 500 ?
        <div className="menulist-container row">
            {startIndex !== 0 ? 
            <div className={`menulist-menu ${window.innerWidth <= 550 ? 'col-1' : null}`}>
                <img src={left_arrow} alt="search" onClick={() => leftArrowFunc()} className="arrow-image"/>
            </div> 
             : <div className={`menulist-menu ${window.innerWidth <= 550 ? 'col-1' : null}`}></div>}
            <div className={`menulist-menu-row ${window.innerWidth <= 550 ? 'col-1' : null}`}>
                {currentMenuList && currentMenuList.length ? currentMenuList.map(item => (
                    <React.Fragment>
                        <div className="menulist-menu">
                            <button type="button" className={`menu-button ${selectedMenu === item.id ? 'selected' : null}`} onClick={() => setSelectedMenuCategory(item.id)}>
                                <span>
                                    {console.log("Item: ", item)}
                                    <img src={item.image} alt={item.type} className="menu-image"/>
                                </span> 
                                {window.innerWidth <= 768 ? <div className="menubutton-name">
                                    {item.type.toUpperCase()}
                                </div> : item.type.toUpperCase()}
                            </button>
                        </div>
                    </React.Fragment>
                )) : null}
            </div>
            {menu && menu.category && endIndex !== menu.category.length ? <div className={`menulist-menu ${window.innerWidth <= 550 ? 'col-1' : null}`}>
                <img src={right_arrow} alt="search" onClick={() => rightArrowFunc()} className="arrow-image"/>
            </div> : <div className={`menulist-menu ${window.innerWidth <= 550 ? 'col-1' : null}`}></div>}
        </div>
        // :
        // <div className="menulist-container row">
        //     <div className="menulist-menu">
        //         <img src={left_arrow} alt="search" onClick={() => leftArrowFunc()} className="arrow-image"/>
        //     </div> 
        //     <div className="menulist-menu-row">
        //         {currentMenuList && currentMenuList.length ? currentMenuList.map(item => (
        //                 <React.Fragment>
        //                     <div className="menulist-menu col">
        //                         <button type="button" className={`menu-button ${selectedMenu === item.id ? 'selected' : null}`} onClick={() => setSelectedMenuCategory(item.id)}>
        //                             <span>
        //                                 <img src={item.image.default} alt={item.type} className="menu-image"/>
        //                             </span> 
        //                             <div className="menubutton-name">
        //                                 {item.type.toUpperCase()}
        //                             </div>
        //                         </button>
        //                     </div>
        //                 </React.Fragment>
        //             )) : null}
        //     </div>
        //     <div className="menulist-menu">
        //         <img src={right_arrow} alt="search" onClick={() => rightArrowFunc()} className="arrow-image"/>
        //     </div>
        // </div>
    )
}

export default MenuList;

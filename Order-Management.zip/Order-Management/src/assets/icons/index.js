export { default as search } from "./Union1.png";
export { default as Green_icon } from "./Green_icon.png";
export { default as white_icon } from "./white_icon.png";
export { default as Logout } from "./Group 70.png";
export { default as OrderImage } from "./Path 27.png";
export { default as Home } from "./Group 69.png";
export { default as CheckoutImage } from "./Path 31.png";
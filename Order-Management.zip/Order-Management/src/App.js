import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Order from './Components/Order/order';
import HeaderComp from './Components/Login/Login';
import { GlobalContextProvider } from './context/globalContext';

function App() {
  return (
    <Router>
      <GlobalContextProvider>
        <Routes>
          <Route
            path="/" // Route to home page/landing page/search page
            element={<HeaderComp />}
          />
          <Route
            path="/Order" // Route to order page
            element={<Order />}
          />
        </Routes>
      </GlobalContextProvider>
    </Router>
  );
}

export default App;

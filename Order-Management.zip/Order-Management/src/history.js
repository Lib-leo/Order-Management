import { createBrowserHistory } from 'history'

//To create a browser history
export const history = createBrowserHistory()